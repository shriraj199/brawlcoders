const search_button = document.getElementById("search-button")
const search_bar = document.getElementById("search-bar").addEventListener("focus", () => {
    const search_bar = document.getElementById("search-bar")
    search_bar.addEventListener("keypress", (e) => {
        // console.log("Heloo")
        console.log(search_bar.value)

        if (e.code == "Enter") {

            if (search_bar.value.trim() == "") {
                console.log("Heloo")
                search_button.click()
            }
        }
    })
})

search_button.addEventListener("click", (e) => {
    console.log("Done")

})