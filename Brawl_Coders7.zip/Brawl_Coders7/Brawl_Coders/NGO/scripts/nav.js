/* MOBILE MENU */

const nav_btn = document.querySelector("#nav_btn");
								const nav_bg = document.querySelector("#nav_bg");
								const nav_main = document.querySelector("#nav_main");
								
								nav_btn.addEventListener("click", () => {
												nav_bg.classList.toggle("hidden");
												nav_main.classList.toggle("hidden");
												document.body.classList.toggle("overflow-hidden");
												
												if (nav_bg.classList.contains("hidden")) {
    
    	nav_btn.innerHTML=`
    	<svg xmlns="http://www.w3.org/2000/svg" class=" w-full h-full p-4 my-auto icon icon-tabler icon-tabler-menu" width="30" height="30" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <line x1="4" y1="8" x2="20" y2="8" />
  <line x1="4" y1="16" x2="20" y2="16" />
</svg>
    	`;

document.body.classList.remove("overflow-hidden");
  } else {
  	nav_btn.innerHTML=`
  	<svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full p-4 my-auto icon icon-tabler icon-tabler-x" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <line x1="18" y1="6" x2="6" y2="18" />
  <line x1="6" y1="6" x2="18" y2="18" />
</svg>

  	`;
    
    document.body.classList.add("overflow-hidden");
  }
								});
								
								nav_bg.addEventListener("click", () => {
												nav_bg.classList.toggle("hidden");
												nav_main.classList.toggle("hidden");
																					
												if (nav_bg.classList.contains("hidden")) {
    
    	nav_btn.innerHTML=`
    		<svg xmlns="http://www.w3.org/2000/svg" class=" w-full h-full p-4 my-auto icon icon-tabler icon-tabler-menu" width="30" height="30" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <line x1="4" y1="8" x2="20" y2="8" />
  <line x1="4" y1="16" x2="20" y2="16" />
</svg>
    	`;
    	
    	document.body.classList.remove("overflow-hidden");

  } else {
  	nav_btn.innerHTML=`
  	<svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full p-4 my-auto icon icon-tabler icon-tabler-x" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <line x1="18" y1="6" x2="6" y2="18" />
  <line x1="6" y1="6" x2="18" y2="18" />
</svg>
  	`;
    
    document.body.classList.add("overflow-hidden");
  }
								});


/* MOBILE SEARCH */

const mob_search = document.querySelector("#mob_search");
								const search_btn = document.querySelector("#search_btn");
								
								search_btn.addEventListener("click", () => {
												mob_search.classList.toggle("hidden");
												
												
															
												if (mob_search.classList.contains("hidden")) {
    
    	search_btn.innerHTML=`
    	<svg xmlns="http://www.w3.org/2000/svg" class="w-7 h-7 icon icon-tabler icon-tabler-search" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <circle cx="10" cy="10" r="7" />
  <line x1="21" y1="21" x2="15" y2="15" />
</svg>
    	`;
document.body.classList.remove("overflow-hidden");
  } else {
  	search_btn.innerHTML=`
  	<svg xmlns="http://www.w3.org/2000/svg" class="w-7 h-7 icon icon-tabler icon-tabler-x" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
  <line x1="18" y1="6" x2="6" y2="18" />
  <line x1="6" y1="6" x2="18" y2="18" />
</svg>
  	`;
    
    document.body.classList.add("overflow-hidden");
  }
								});
