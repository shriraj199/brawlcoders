$(".file-inp").on("change", function (e) {
    const hello = e.target.id
    const name = document.getElementById(hello).files.item(0).name;
    document.getElementById(hello + '-text').innerHTML = name;
})