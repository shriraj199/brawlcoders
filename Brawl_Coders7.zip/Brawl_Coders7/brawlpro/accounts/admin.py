from django.contrib import admin
from accounts.models import *

# Register your models here.
admin.site.register(Nominee)
admin.site.register(ngo)
admin.site.register(Employee)
admin.site.register(Profile)
admin.site.register(Photos)