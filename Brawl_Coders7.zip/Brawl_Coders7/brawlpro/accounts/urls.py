import imp
from re import template
from django.contrib import admin
from django.urls import path,include
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('rp',views.registerpatient),
    path('rn',views.registernominee),
    path('em',views.employee),
    path('em2',views.employee2),
    path('nextform',views.saveregister,name='nextform'),
    path('list',views.list),
    path('emlist',views.emlist),
    path('palist',views.palist),
    path('login',auth_views.LoginView.as_view(template_name='login2.html')),
    path('logout/',views.logout,name='logout'),
    path('profile',views.profile,name='profile'),
]
