from email.policy import default
from django.db import models
from django.contrib.auth.models import User
from PIL import Image
from django.core.validators import validate_image_file_extension,FileExtensionValidator
from django.dispatch import receiver 
from django.db.models.signals import post_save
# Create your models here.
class Nominee(models.Model):
    firstname= models.CharField(max_length=30)
    midname= models.CharField(max_length=30)
    lastname= models.CharField(max_length=30)
    dob = models.CharField(max_length=20)
    mobile = models.CharField(max_length=13)
    email= models.EmailField()
    country=models.CharField(max_length=50)
    state=models.CharField(max_length=50)
    pcode=models.CharField(max_length=20)
    current_add=models.CharField(max_length=225)
    permanent_add=models.CharField(max_length=225)
    aadhar_no=models.CharField(max_length=12)
    aadhar_name=models.CharField(max_length=30)
    pan_no=models.CharField(max_length=13)
    pan_name=models.CharField(max_length=30)
    blood_group=models.CharField(max_length=10)
    height=models.CharField(max_length=20)
    weight=models.CharField(max_length=20)
    edu=models.CharField(max_length=35)
    university=models.CharField(max_length=40)
    college=models.CharField(max_length=40)

    def __str__(self):
        return self.firstname +' '+ self.lastname

class ngo(models.Model):
    name=models.CharField(max_length=50)
    def __str__(self):
        return self.name

class Employee(models.Model):
    organisation=models.CharField(max_length=50)
    name= models.CharField(max_length=30)
    employee_dob = models.CharField(max_length=20)
    employee_mobile = models.CharField(max_length=13)
    employee_email= models.EmailField()
    employee_country=models.CharField(max_length=50)
    employee_state=models.CharField(max_length=50)
    employee_pcode=models.CharField(max_length=20)
    employee_current_add=models.CharField(max_length=225)
    employee_permanent_add=models.CharField(max_length=225)
    employee_aadhar_no=models.CharField(max_length=12)
    employee_aadhar_name=models.CharField(max_length=30)
    employee_pan_no=models.CharField(max_length=13)
    employee_pan_name=models.CharField(max_length=30)
    employee_bio=models.CharField(max_length=225)
    employee_password=models.CharField(max_length=40)
    employee_blood_group=models.CharField(max_length=10)
    employee_height=models.CharField(max_length=20)
    employee_weight=models.CharField(max_length=20)
    employee_edu=models.CharField(max_length=35)
    employee_university=models.CharField(max_length=40)
    employee_college=models.CharField(max_length=40)

    def __str__(self):
        return self.name

class Profile (models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    about=models.CharField(max_length=200,blank=True)
    image=models.ImageField(default='img/default.jpeg',upload_to='Profile_Pics',blank=True,null=True,validators=[validate_image_file_extension])


    def __str__(self):
        return str(self.user)

class Photos(models.Model):
    dp=models.ImageField(default='img/default.jpeg',upload_to='Profile_Pics',blank=True,null=True,validators=[validate_image_file_extension])
    aadhar=models.FileField(blank=False,null=False,upload_to='Notes',validators=[FileExtensionValidator(allowed_extensions=['pdf'])])
    pan=models.FileField(blank=False,null=False,upload_to='Notes',validators=[FileExtensionValidator(allowed_extensions=['pdf'])])

    # @receiver(post_save, sender=User)
    # def create_user_profile(sender, instance, created, **kwargs):
    #     if created:
    #         Profile.objects.create(user=instance)

    # @receiver(post_save, sender=User)
    # def save_user_profile(sender, instance, **kwargs):
    #     instance.profile.save()
    
    # def save(self,*args, **kwargs):
    #     super(Profile, self).save(*args, **kwargs)
    #     img = Image.open(self.image.path)
    #     if img.height > 300 or img.width > 300 or img.height < 300 or img.width < 300 :
    #         output_size = (300, 300)
    #         img.thumbnail(output_size)
    #         img.save(self.image.path)

    # class Meta:
    #     verbose_name_plural='Profile'