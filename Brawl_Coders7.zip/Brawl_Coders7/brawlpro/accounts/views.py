from pickle import NONE
from pyexpat import model
from django.shortcuts import redirect, render
from numpy import require
from django.http import HttpResponseRedirect
from accounts.models import *
from django.views.generic import ListView
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_sign
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

import json

# Create your views here.
def registerpatient(request):
    return render(request,'form1.html')
def saveregister(request):
    if request.method=='POST':
        firstname=request.POST.get('fname')
        midname=request.POST.get('mname')
        lastname=request.POST.get('lname')
        dob=request.POST.get('dob')
        mobile=request.POST.get('mobile')
        email=request.POST.get('email')
        country=request.POST.get('country')
        state=request.POST.get('state')
        print(state)
        pcode=request.POST.get('pcode')
        current_add=request.POST.get('cadd')
        permanent_add=request.POST.get('padd')
        aadhar_no=request.POST.get('aadhar1') + request.POST.get('aadhar2') + request.POST.get('aadhar3')
        aadhar_name=request.POST.get('nameaadhar')
        pan_no=request.POST.get('pan1') + request.POST.get('pan2') 
        pan_name=request.POST.get('panname')
        blood_group=request.POST.get('bloodg')
        height=request.POST.get('height')
        weight=request.POST.get('weight')
        edu=request.POST.get('edu')
        university=request.POST.get('university')
        college=request.POST.get('college')
        en=Nominee(firstname=firstname,midname=midname,lastname=lastname,dob=dob,mobile=mobile,email=email,country=country,state=state,pcode=pcode,current_add=current_add,permanent_add=permanent_add,aadhar_no=aadhar_no,aadhar_name=aadhar_name,pan_no=pan_no,pan_name=pan_name,blood_group=blood_group,height=height,weight=weight,edu=edu,university=university,college=college)
        en.save()
        
    return render(request,'form1-2.html')
def registernominee(request):
    return render(request,'form1-2.html')
    
def employee(request):
    allngo=ngo.objects.all()
    context={'ngos':allngo}
    if request.method=='POST':
        organisation=request.POST.get('organisation')
        print(organisation)
        name=request.POST.get('employee_fname') + '' + request.POST.get('employee_mname') + '' + request.POST.get('employee_lname')
        employee_dob=request.POST.get('employee_dob')
        employee_mobile=request.POST.get('employee_mobile')
        employee_email=request.POST.get('employee_email')
        employee_country=request.POST.get('employee_country')
        employee_state=request.POST.get('employee_state')
        employee_pcode=request.POST.get('employee_pcode')
        employee_current_add=request.POST.get('employee_cadd')
        employee_permanent_add=request.POST.get('employee_padd')
        employee_aadhar_no=request.POST.get('employee_aadhar1') + request.POST.get('employee_aadhar2') + request.POST.get('employee_aadhar3')
        employee_aadhar_name=request.POST.get('employee_aadharname')
        employee_pan_no=request.POST.get('employee_pan1') + request.POST.get('employee_pan2') 
        employee_pan_name=request.POST.get('employee_panname')
        employee_bio=request.POST.get('employee_bio')
        employee_password=request.POST.get('employee_password')
        employee_blood_group=request.POST.get('employee_bg')
        employee_height=request.POST.get('employee_height')
        employee_weight=request.POST.get('employee_weight')
        employee_edu=request.POST.get('employee_edu')
        employee_university=request.POST.get('employee_board')
        employee_college=request.POST.get('employee_college')

        en=Employee(organisation=organisation,name=name,employee_dob=employee_dob,employee_mobile=employee_mobile,employee_email=employee_email,employee_country=employee_country,employee_state=employee_state,employee_pcode=employee_pcode,employee_current_add=employee_current_add,employee_permanent_add=employee_permanent_add,employee_aadhar_no=employee_aadhar_no,employee_aadhar_name=employee_aadhar_name,employee_pan_no=employee_pan_no,employee_pan_name=employee_pan_name,employee_bio=employee_bio,employee_password=employee_password,employee_blood_group=employee_blood_group,employee_height=employee_height,employee_weight=employee_weight,employee_edu=employee_edu,employee_university=employee_university,employee_college=employee_college)
        en.save()
        entry=User.objects.create_user(username=name,email=employee_email,password=employee_password)
        entry.save()
        return render(request,'em-form1.html')

    return render(request,'em-form1.html',context)
    

def employee2(request):
    if request.method=='POST':
        dp=request.POST.get('dp')
        aadhar=request.POST.get('aadhar')
        pan=request.POST.get('pan')

        en=Photos(dp=dp,aadhar=aadhar,pan=pan)
        en.save()
    return render(request,'em-form2.html')



@login_required
def list(request):
    if request.method == 'POST':
        searched=request.POST.get('searched')
        q1=ngo.objects.filter(name__contains=searched)
        context={'q1':q1,'searched':searched}
        return render(request,'search-list.html',context)
    allngo=ngo.objects.all()
    print(allngo)
    context={'ngos':allngo}
    return render(request,'list.html',context)

@login_required
def emlist(request):
    if request.method == 'POST':
        searched=request.POST.get('emsearched')
        q2=Employee.objects.filter(name__contains=searched)
        context={'q2':q2,'searched':searched}
        return render(request,'search-em.html',context)
    allemp=Employee.objects.all()
    print(allemp)
    context={'employee':allemp}
    return render(request,'em-list.html',context)

@login_required
def palist(request):
    if request.method == 'POST':
        searched=request.POST.get('pasearched')
        q2=Nominee.objects.filter(firstname__contains=searched)
        context={'q2':q2,'searched':searched}
        return render(request,'pa-list.html',context)
    allnom=Nominee.objects.all()
    print(allnom)
    context={'nominee':allnom}
    return render(request,'pa-list.html',context)

@login_required
def profile(request):
    if request.user.is_authenticated:
        queryset1=Photos.objects.all()
        print(queryset1)
        queryset2=Profile.objects.all()
        print(queryset2)
        return render(request,'profile.html',{'queryset1':queryset1,'queryset2':queryset2})
    return render(request,'profile.html')

def logout(request):
    auth_logout(request)
    return redirect('/accounts/login')
# class InfoListView(ListView):
#     model=ngo
#     template_name='list.html'

#     def get_context_data(self, **kwargs):
#         cont=super().get_context_data(**kwargs)
#         cont['qs_json']= json.dumps(list(ngo.objects.values()))
#         return cont