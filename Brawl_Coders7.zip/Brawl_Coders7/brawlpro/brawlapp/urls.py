from unicodedata import name
from django.contrib import admin
from django.urls import path,include
from . import views
app_name='home'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    path('dashboard',views.dashboard,name='dashboard'),
    path('reg',views.reg,name='reg'),
    path('announce',views.announce,name='announce'),

]
