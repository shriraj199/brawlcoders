import imp
from django.shortcuts import render
from accounts.models import *
# Create your views here.
def index(request):
    return render(request,'index.html')
def dashboard(request):
    if request.user.is_authenticated:
        q1=Employee.objects.all()
        return render(request,'dashboard.html',{'q1':q1})
def reg(request):
    return render(request,'reg-type.html')
def announce(request):
    return render(request,'announce.html')

